GOLD AMN + SMC — live-feed add-on

WHAT THIS DOES
- Tries to retrieve public XAUUSD=X 1-minute, 15-minute and 1-hour candles.
- Builds 4-hour candles from the hourly feed.
- Refreshes every 60 seconds while the web app is open.
- Keeps the existing CSV upload as a fallback.

IMPORTANT LIMITATIONS
- This uses an experimental public Yahoo Finance chart endpoint, not an Exness/MT5 feed.
- Yahoo may delay, restrict or change the endpoint; if so, the add-on reports an error.
- 4H candles are resampled from hourly data.
- The iPhone browser must remain open for periodic refresh; no guaranteed background alerts.
- It does not place trades or connect to your Exness account.

INSTALL
1. In the existing index.html, add this card immediately before the section titled
   "1. Load candle data":

<section class="card">
  <h2>Automatic XAUUSD data</h2>
  <p class="hint">Public XAUUSD feed; refreshes every 60 seconds while this page is open.</p>
  <div class="actions">
    <button id="liveConnect">Connect live data</button>
    <button class="secondary" id="liveStop">Stop auto-refresh</button>
  </div>
  <div class="hint" id="liveStatus">Not connected. Tap Connect live data.</div>
</section>

2. Add this line immediately after the existing main application script and before
   the service-worker script:
   <script src="./live-feed-addon.js"></script>

3. Upload live-feed-addon.js into the repository root (same folder as index.html).
4. Save index.html and wait for GitHub Pages to publish.

If the feed is blocked by the browser/provider, continue using the CSV upload.
The analyzer is a screening aid only; verify every setup manually and risk no more
than 1% per trade.
