GOLD AMN + SMC ANALYZER — PWA package

Files:
- index.html: analyzer app
- manifest.webmanifest: installable app metadata
- sw.js: offline caching for app shell
- icon.svg: app icon

Publish these four files at the ROOT of a GitHub Pages site over HTTPS.
On iPhone: open the published site in Safari, tap Share, then Add to Home Screen.

Notes:
- TradingView's embedded chart needs an internet connection.
- CSV candle upload and analysis run in the browser.
- This prototype does not connect directly to Exness or place trades.
- Demo candles are illustrative, not live market data.
